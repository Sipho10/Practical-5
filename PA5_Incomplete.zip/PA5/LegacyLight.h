#include <string>
#include <iostream>

using namespace std;

class LegacyLight
{
   private:
    bool LegacyIsOn ;
   public:
    LegacyLight();
    void switchOn();
    void switchOff();
};