#include "LegacyThermostat.h"
#include "SmartDevice.h"

class SmartThermostatIntegrator : public SmartDevice
{
    private:
        LegacyThermostat* oldDawg;
    public:

        SmartThermostatIntegrator();
        void setThermostat(LegacyThermostat* coolCat);
        void performAction(string command);
        void setTemperature(int temp);
        int getTemperature();
};