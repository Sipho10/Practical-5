#include "Command.h"

class WarmRoomCommand : public Command 
{
    private:
        SmartDevice* device;

    public:
        WarmRoomCommand(SmartDevice* device);
        void execute();
};