#include "Command.h"

class TurnOffLightCommand : public Command 
{
    private:
        SmartDevice* device;

    public:
        TurnOffLightCommand(SmartDevice* device);
        void execute();
};