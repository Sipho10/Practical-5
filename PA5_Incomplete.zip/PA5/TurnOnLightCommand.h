#include "Command.h"

class TurnOnLightCommand : public Command 
{
    private:
        SmartDevice* device;

    public:
        TurnOnLightCommand(SmartDevice* device);
        void execute();
};