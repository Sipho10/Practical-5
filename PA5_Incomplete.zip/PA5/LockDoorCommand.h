#include "Command.h"

class LockDoorCommand : public Command 
{
    private:
        SmartDevice* device;

    public:
        LockDoorCommand(SmartDevice* device);
        void execute();
};