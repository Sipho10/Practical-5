#include "SmartDevice.h"

class DoorLock : public SmartDevice
{
   private:
    bool locked ;
   public:
    DoorLock();
    void performAction(string command);
    void update();
};