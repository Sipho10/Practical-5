#include "Room.h"
#include <iostream>

Room::Room(const string& name) : roomName(name)
{

}

bool Room::addDevice(const string& deviceName, SmartDevice* device) 
{
    auto result = devices.emplace(deviceName, device);
    return result.second;
}

bool Room::removeDevice(const string& deviceName) 
{
    return devices.erase(deviceName) > 0; 
}

void Room::performAction(const string& deviceName, const string& command) 
{
    auto it = devices.find(deviceName);
    if(it != devices.end()) 
    {
        it->second->performAction(command);
    } 
    else 
    {
        cout << "Device " << deviceName << " not found in room " << roomName << "." << endl;
    }
}

void Room::getStatus() const 
{
    std::cout << "Room " << roomName << " status:" << std::endl;
    for (const auto& pair : devices) 
    {
        std::cout << pair.first << " (" << pair.second->getDeviceType() << "): "
                  << pair.second->getStatus() << std::endl;
    }
}

string Room::getRoomName() const 
{
    return roomName;
}
