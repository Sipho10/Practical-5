#include "SmartDoorLockIntegrator.h"

void SmartDoorLockIntegrator::performAction(string command)
{
    if(command == "Lock")
    {
        oldDawg->lock();
        setStatus("locked");
    }
    else if(command == "Unlock")
    {
        oldDawg->unlock();
        setStatus("unlocked");
    }
    else if(command == "Toggle") 
    {
        if(getStatus()=="unlocked")
        {
            oldDawg->lock();
            setStatus("locked");
        }
        else
        {
            oldDawg->unlock();
            setStatus("unlcoked");
        }
    }
    else
    {
        cout<<"Invalid Command."<<endl;
    }
}

void SmartDoorLockIntegrator::setDoorLock(LegacyDoorLock* coolCat)
{
    oldDawg = coolCat;
}

SmartDoorLockIntegrator::SmartDoorLockIntegrator(LegacyDoorLock* coolCat)
{
    oldDawg = coolCat;
    setStatus("unlocked");
    setDeviceType("DoorLock");
    oldDawg->unlock();
}

void SmartDoorLockIntegrator::update()
{
    std::cout << "Door locked due to movement detection." << std::endl;
    this->performAction("Locked");
}
