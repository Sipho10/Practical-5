#ifndef SMARTDOORLOCKINTEGRATOR_H
#define SMARTDOORLOCKINTEGRATOR_H

#include "LegacyDoorLock.h"
#include "SmartDevice.h"

class SmartDoorLockIntegrator : public SmartDevice
{
    private:
        LegacyDoorLock* oldDawg;
    public:

        SmartDoorLockIntegrator(LegacyDoorLock* coolCat);
        void setDoorLock(LegacyDoorLock* coolCat);
        void performAction(string command);
        void update();
};

#endif