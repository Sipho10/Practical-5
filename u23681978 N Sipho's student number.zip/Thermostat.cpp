#include "Thermostat.h"

Thermostat::Thermostat()
{
    isOn = false;
    setStatus("off");
    setDeviceType("Thermostat");
}

void Thermostat::performAction(string command)
{
    if(command == "ToggleOn")
    {
        isOn = true;
        setStatus("on");
    }
    else if(command == "ToggleOff")
    {
        isOn = false;
        setStatus("off");
    }
    else if(command == "Toggle") 
    {
        isOn = !isOn;
        if(isOn)
        {
            setStatus("on");
        }
        else
        {
            setStatus("off");
        }
    }
    else if(command == "Warm Up") 
    {
        setStatus("on");
        setTemp(25);
    }
    else if(command == "Cool Down") 
    {
        setStatus("on");
        setTemp(18);
    }
    else
    {
        cout<<"Invalid Command."<<endl;
    }
}

void Thermostat::setTemp(int temp)
{
    if(isOn)
    temperature = temp;
    else
    cout<<"First switch on the thermometer"<<endl;
}

void Thermostat::update()
{
    std::cout << "Thermostat adjusting due to movement detection and cooling room based on user preferences." << std::endl;
    this->performAction("Cool Down");

}
