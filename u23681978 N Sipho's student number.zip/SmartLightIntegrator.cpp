#include "SmartLightIntegrator.h"

void SmartLightIntegrator::performAction(string command)
{
    if(command == "ToggleOn")
    {
        oldDawg->switchOn();
        setStatus("on");
    }
    else if(command == "ToggleOff")
    {
        oldDawg->switchOff();
        setStatus("off");
    }
    else if(command == "Toggle") 
    {
        if(getStatus()=="off")
        {
            oldDawg->switchOn();
            setStatus("on");
        }
        else
        {
            oldDawg->switchOff();
            setStatus("off");
        }
    }
    else
    {
        cout<<"Invalid Command."<<endl;
    }
}


void SmartLightIntegrator::setLight(LegacyLight* coolCat)
{
    oldDawg = coolCat;
}

SmartLightIntegrator::SmartLightIntegrator(LegacyLight* coolCat)
{
    oldDawg = coolCat;
    setStatus("off");
    setDeviceType("Light");
    oldDawg->switchOff();
}

void SmartLightIntegrator::update()
{
     std::cout << "Light turned on due to movement detection." << std::endl;
     this->performAction("ToggleOn");

}