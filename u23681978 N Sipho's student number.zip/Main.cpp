#include "Light.h"
#include "DoorLock.h"
#include "Thermostat.h"
#include "Room.h"
#include "SmartThermostatIntegrator.h"
#include "SmartDoorLockIntegrator.h"
#include "SmartLightIntegrator.h"
#include "SleepMode.h"
#include "TurnOffLightCommand.h"
#include "TurnOnLightCommand.h"
#include "WarmRoomCommand.h"
#include "LockDoorCommand.h"
#include "LegacyDoorLock.h"
#include "LegacyLight.h"
#include "LegacyThermostat.h"
#include "Sensor.h"

int main()
{

    Light* light1 = new Light();
    Thermostat* thermostat1 = new Thermostat();
    DoorLock* doorLock1 = new DoorLock();
    LegacyDoorLock* legacyDoorLock1 = new LegacyDoorLock();
    LegacyLight* legacyLight1 = new LegacyLight();
    LegacyThermostat* legacyThermostat1 = new LegacyThermostat();
    SmartThermostatIntegrator* STI = new SmartThermostatIntegrator(legacyThermostat1); 
    SmartDoorLockIntegrator* SDLI = new SmartDoorLockIntegrator(legacyDoorLock1);
    SmartLightIntegrator* SLI = new SmartLightIntegrator(legacyLight1);
    Room* livingRoom = new Room("Living Room");
    Room* bedroom = new Room("Bedroom");
    SleepMode* sleepMode = new SleepMode(light1,doorLock1,thermostat1);
    TurnOffLightCommand* TOLC = new TurnOffLightCommand(light1); 
    TurnOnLightCommand* TOLC2 = new TurnOnLightCommand(light1);
    WarmRoomCommand* WRC = new WarmRoomCommand(thermostat1);
    LockDoorCommand* LDC = new LockDoorCommand(doorLock1);
    light1->getDeviceType();
    light1->getStatus();
    light1->performAction("ToggleOn");
    light1->performAction("ToggleOff");
    light1->performAction("Toggle");
    thermostat1->getDeviceType();
    thermostat1->getStatus();
    thermostat1->performAction("ToggleOn");
    thermostat1->performAction("ToggleOff");
    thermostat1->performAction("Toggle");
    thermostat1->performAction("Warm Up");
    thermostat1->performAction("Cool Down");
    doorLock1->getDeviceType();
    doorLock1->getStatus();
    doorLock1->performAction("Lock");
    doorLock1->performAction("Unlock");
    doorLock1->performAction("Toggle");


    return 0;
}