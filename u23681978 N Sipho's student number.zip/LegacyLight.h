#ifndef LEGACYLIGHT_H
#define LEGACYLIGHT_H

#include <string>
#include <iostream>

using namespace std;

class LegacyLight
{
   private:
    bool LegacyIsOn ;
   public:
    LegacyLight();
    void switchOn();
    void switchOff();
};

#endif