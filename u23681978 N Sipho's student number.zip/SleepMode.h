#ifndef SLEEPMODE_H
#define SLEEPMODE_H

#include "Command.h"
#include <map>


class SleepMode//Macro routine
{
    private:
        map<string, Command*> commands;
    public:
        SleepMode(SmartDevice* light,SmartDevice* lock,SmartDevice* heater);
        void execute();
        bool addProcedure(string commandName , Command* command);
        bool removeProcedure(string commandName );
     


};

#endif