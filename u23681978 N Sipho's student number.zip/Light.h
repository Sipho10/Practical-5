#ifndef LIGHT_H
#define LIGHT_H

#include "SmartDevice.h"

class Light : public SmartDevice
{
   private:
    bool isOn ;
   public:
    Light();
    void performAction(string command);
    void update();
    

};

#endif