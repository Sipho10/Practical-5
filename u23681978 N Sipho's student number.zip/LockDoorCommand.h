#ifndef LOCKDOORCOMMAND_H
#define LOCKDOORCOMMAND_H

#include "Command.h"

class LockDoorCommand : public Command 
{
    private:
        SmartDevice* device;

    public:
        LockDoorCommand(SmartDevice* device);
        void execute();
};

#endif