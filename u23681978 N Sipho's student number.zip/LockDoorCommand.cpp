#include "LockDoorCommand.h"

LockDoorCommand::LockDoorCommand(SmartDevice* device)
{
    this->device = device;
}
void LockDoorCommand::execute()
{
    device->performAction("Lock");
}