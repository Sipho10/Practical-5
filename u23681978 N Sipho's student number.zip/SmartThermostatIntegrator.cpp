#include "SmartThermostatIntegrator.h"

void SmartThermostatIntegrator::performAction(string command)
{
    if(command == "ToggleOn")
    {
        oldDawg->switchOn();
        setStatus("on");
    }
    else if(command == "ToggleOff")
    {
        oldDawg->switchOff();
        setStatus("off");
    }
    else if(command == "Toggle") 
    {
        if(getStatus()=="off")
        {
            oldDawg->switchOn();
            setStatus("on");
        }
        else
        {
            oldDawg->switchOff();
            setStatus("off");
        }
    }
    else if(command == "Warm Up") 
    {
        setStatus("on");
        oldDawg->LegacySetTemp(25);
    }
    else if(command == "Cool Down") 
    {
        setStatus("on");
        oldDawg->LegacySetTemp(18);
    }
    else
    {
        cout<<"Invalid Command."<<endl;
    }
}

void SmartThermostatIntegrator::setThermostat(LegacyThermostat* coolCat)
{
    oldDawg = coolCat;
}

SmartThermostatIntegrator::SmartThermostatIntegrator(LegacyThermostat* coolCat)
{
    oldDawg = coolCat;
    setStatus("off");
    setDeviceType("Thermostat");
    oldDawg->switchOff();
}

void SmartThermostatIntegrator::setTemperature(int temp)
{
    if(getStatus()=="on")
    {
        oldDawg->LegacySetTemp(temp);
    }
    else
    {
       cout<<"First switch on the thermometer"<<endl;
    }
}

int SmartThermostatIntegrator::getTemperature()
{
    return oldDawg->LegacyGetTemp();
}

void SmartThermostatIntegrator::update()
{
    std::cout << "Thermostat adjusting due to movement detection and cooling room based on user preferences." << std::endl;
    this->performAction("Cool Down");
}