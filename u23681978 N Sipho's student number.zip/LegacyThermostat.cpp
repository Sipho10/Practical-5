#include "LegacyThermostat.h"

LegacyThermostat::LegacyThermostat()
{
    LegacyIsOn = false;
}
void LegacyThermostat::LegacySetTemp(int temp)
{
    if(LegacyIsOn)
    LegacyTemperature = temp;
}
void LegacyThermostat::switchOn()
{
    LegacyIsOn = true;
}
void LegacyThermostat::switchOff()
{
    LegacyIsOn = false;
}

int LegacyThermostat::LegacyGetTemp()
{
    return LegacyTemperature;
}