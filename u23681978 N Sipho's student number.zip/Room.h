#ifndef ROOM_H
#define ROOM_H

#include <map>
#include <string>
#include "SmartDevice.h" // Assuming SmartDevice.h contains the declaration of SmartDevice

using namespace std;

class Room 
{
    private:

        string roomName;
        map<string, SmartDevice*> devices;

    public:

        Room(const string& name);
        bool addDevice(const string& deviceName, SmartDevice* device);
        bool removeDevice(const string& deviceName);
        void performAction(const string& deviceName, const string& command);
        void getStatus() const;
        string getRoomName() const;

};

#endif
