#ifndef TURNOFFLIGHTCOMMAND_H
#define TURNOFFLIGHTCOMMAND_H

#include "Command.h"

class TurnOffLightCommand : public Command 
{
    private:
        SmartDevice* device;

    public:
        TurnOffLightCommand(SmartDevice* device);
        void execute();
};

#endif