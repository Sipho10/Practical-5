#include "TurnOnLightCommand.h"

TurnOnLightCommand::TurnOnLightCommand(SmartDevice* device)
{
    this->device = device;
}
void TurnOnLightCommand::execute()
{
    device->performAction("ToggleOn");
}