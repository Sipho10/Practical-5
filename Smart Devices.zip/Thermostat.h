#ifndef THERMOSTAT_H
#define THERMOSTAT_H

#include "SmartDevice.h"

class Thermostat : public SmartDevice
{
   private:
    bool isOn ;
    int temperature;
   public:
    Thermostat();
    void performAction(string command);
    void setTemp(int temp);
    void update();
    

};

#endif