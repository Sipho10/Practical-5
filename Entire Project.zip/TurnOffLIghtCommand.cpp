#include "TurnOffLightCommand.h"

TurnOffLightCommand::TurnOffLightCommand(SmartDevice* device)
{
    this->device = device;
}
void TurnOffLightCommand::execute()
{
    device->performAction("ToggleOff");
}