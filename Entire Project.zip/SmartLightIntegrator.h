#ifndef SMARTLIGHTINTEGRATOR_H
#define SMARTLIGHTINTEGRATOR_H

#include "LegacyLight.h"
#include "SmartDevice.h"

class SmartLightIntegrator : public SmartDevice
{
    private:
        LegacyLight* oldDawg;
    public:

        SmartLightIntegrator(LegacyLight* coolCat);
        void setLight(LegacyLight* coolCat);
        void performAction(string command);
        void update();

};

#endif