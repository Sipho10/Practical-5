#ifndef LEGACYDOORLOCK_H
#define LEGACYDOORLOCK_H

#include <string>
#include <iostream>

using namespace std;

class LegacyDoorLock
{
   private:
    bool LegacyLocked ;
   public:
    LegacyDoorLock();
    void lock();
    void unlock();
};

#endif