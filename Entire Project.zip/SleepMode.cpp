#include "SleepMode.h"
#include "TurnOnLightCommand.h"
#include "TurnOffLightCommand.h"
#include "LockDoorCommand.h"
#include "WarmRoomCommand.h"

SleepMode::SleepMode(SmartDevice* light,SmartDevice* lock,SmartDevice* heater)
{
    addProcedure("TurnOffLightsCommand",new TurnOffLightCommand(light));
    addProcedure("LockDoorCommand",new LockDoorCommand(lock));
    addProcedure("WarmUpCommand",new WarmRoomCommand(heater));
}

void SleepMode::execute()
{
    for(auto pair : commands)
    {
        pair.second->execute();
    }
}

bool SleepMode::addProcedure(string commandName , Command* command)
{
    int ogSize = commands.size();
    commands[commandName] = command;
    if(commands.size() > ogSize)
    {
        return true;
    }

    return false;

}
bool SleepMode::removeProcedure(string commandName)
{
    if(commands.erase(commandName) > 0) 
    {
        return true;
    }
    
    return false;
}

