#ifndef LEGACYTHERMOSTAT_H
#define LEGACYTHERMOSTAT_H

#include <string>
#include <iostream>

using namespace std;

class LegacyThermostat
{
   private:
    bool LegacyIsOn;
    int LegacyTemperature;
   public:
    LegacyThermostat();
    void LegacySetTemp(int temp);
    int LegacyGetTemp();
    void switchOn();
    void switchOff();
    

};

#endif