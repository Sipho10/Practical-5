#include "SmartDevice.h"

void SmartDevice::setDeviceType(string DT)
{
    deviceType = DT;
}
void SmartDevice::setStatus(string S)
{
    status = S;
}
string SmartDevice::getStatus()
{
    return status;
}
string SmartDevice::getDeviceType()
{
    return deviceType;
}