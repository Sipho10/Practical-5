#ifndef WARMROOMCOMMAND_H
#define WARMROOMCOMMAND_H

#include "Command.h"

class WarmRoomCommand : public Command 
{
    private:
        SmartDevice* device;

    public:
        WarmRoomCommand(SmartDevice* device);
        void execute();
};

#endif