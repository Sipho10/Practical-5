#ifndef SENSOR_H
#define SENSOR_H

#include <vector>
#include <algorithm>
#include "SmartDevice.h"
#include "SensorInterface.h"

class Sensor : public SensorInterface
{

public:
    void addDevice(SmartDevice* device);
    void removeDevice(SmartDevice* device);
    void notifyDevices();
    void detectMovement(); // Simulate movement detection
};

#endif
