#ifndef SENSORINTERFACE_H
#define SENSORINTERFACE_H

#include <vector>
#include <algorithm>
#include "SmartDevice.h"

class SensorInterface 
{
protected:
    std::vector<SmartDevice*> devices;

public:
    virtual void addDevice(SmartDevice* device) = 0;
    virtual void removeDevice(SmartDevice* device) = 0;
    virtual void notifyDevices() = 0;
    virtual void detectMovement() = 0;
};

#endif
