#include "DoorLock.h"

DoorLock::DoorLock()
{
    locked = false;
    setStatus("unlocked");
    setDeviceType("DoorLock");
}

void DoorLock::performAction(string command)
{
    if(command == "Lock")
    {
        locked = true;
        setStatus("locked");
    }
    else if(command == "Unlock")
    {
        locked = false;
        setStatus("unlocked");
    }
    else if(command == "Toggle") 
    {
        locked = !locked;
        if(locked)
        {
            setStatus("locked");
        }
        else
        {
            setStatus("unlocked");
        }
    }
    else
    {
        cout<<"Invalid Command."<<endl;
    }
}

void DoorLock::update() {
    std::cout << "Door locked due to movement detection." << std::endl;
    this->performAction("Locked");
}