#include "WarmRoomCommand.h"

WarmRoomCommand::WarmRoomCommand(SmartDevice* device)
{
    this->device = device;
}
void WarmRoomCommand::execute()
{
    device->performAction("Warm Up");
    cout<<"Warming up room"<<endl;
}