#include <string>
#include <iostream>

using namespace std;

class SmartDevice
{
  private:
    string deviceType;
    string status; // Default status is negative
  public:
   virtual void update() = 0;
    virtual void performAction(string command) = 0;
    void setDeviceType(string DT);
    void setStatus(string S);
    string getStatus();
    string getDeviceType();
};