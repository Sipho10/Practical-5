#include "SmartThermostatIntegrator.h"

void SmartThermostatIntegrator::performAction(string command)
{
    if(command == "ToggleOn")
    {
        oldDawg->switchOn();
        setStatus("on");
    }
    else if(command == "ToggleOff")
    {
        oldDawg->switchOff();
        setStatus("off");
    }
    else if(command == "Toggle") 
    {
        if(getStatus()=="off")
        {
            oldDawg->switchOn();
            setStatus("on");
        }
        else
        {
            oldDawg->switchOff();
            setStatus("off");
        }
    }
    else
    {
        cout<<"Invalid Command."<<endl;
    }
}

void SmartThermostatIntegrator::setThermostat(LegacyThermostat* coolCat)
{
    oldDawg = coolCat;
}

SmartThermostatIntegrator::SmartThermostatIntegrator()
{
    setStatus("off");
    setDeviceType("Thermostat");
    oldDawg->switchOff();
}

void SmartThermostatIntegrator::setTemperature(int temp)
{
    if(getStatus()=="on")
    {
        oldDawg->LegacySetTemp(temp);
    }
    else
    {
       cout<<"First switch on the thermometer"<<endl;
    }
}

int SmartThermostatIntegrator::getTemperature()
{
    return oldDawg->LegacyGetTemp();
}