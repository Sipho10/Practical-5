#include <string>
#include <iostream>
#include "SmartDevice.h"

using namespace std;

class Command 
{
    public:
        virtual void execute() = 0;
  
};
