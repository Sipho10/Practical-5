#include "SmartDevice.h"

class Light : public SmartDevice
{
   private:
    bool isOn ;
   public:
    Light();
    void performAction(string command);
    void update();
    

};