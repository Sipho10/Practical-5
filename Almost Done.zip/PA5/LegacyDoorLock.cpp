#include "LegacyDoorLock.h"

LegacyDoorLock::LegacyDoorLock()
{
    LegacyLocked = false;
}

void LegacyDoorLock::lock()
{
    LegacyLocked = true;
}

void LegacyDoorLock::unlock()
{
    LegacyLocked = false;
}