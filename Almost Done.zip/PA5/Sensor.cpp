#include "Sensor.h"
#include <iostream>
#include <vector>


void Sensor::addDevice(SmartDevice* device) {
    devices.push_back(device);
}

void Sensor::removeDevice(SmartDevice* device) {
    auto it = std::find(devices.begin(), devices.end(), device); // Find the device
    if (it != devices.end()) {
        devices.erase(it); // Erase the device if found
    }
}

void Sensor::notifyDevices() {
    for (SmartDevice* device : devices) {
        device->update(); // Notify each device
    }
}

void Sensor::detectMovement() {
    std::cout << "Movement detected!" << std::endl;
    notifyDevices(); // Notify all devices when movement is detected
}
