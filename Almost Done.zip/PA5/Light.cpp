#include "Light.h"

Light::Light()
{
    isOn = false;
    setStatus("off");
    setDeviceType("Light");
}

void Light::performAction(string command)
{
    if(command == "ToggleOn")
    {
        isOn = true;
        setStatus("on");
    }
    else if(command == "ToggleOff")
    {
        isOn = false;
        setStatus("unlocked");
    }
    else if(command == "Toggle") 
    {
        isOn = !isOn;
        if(isOn)
        {
            setStatus("on");
        }
        else
        {
            setStatus("off");
        }
    }
    else
    {
        cout<<"Invalid Command."<<endl;
    }
}

void Light::update()
{
     std::cout << "Light turned on due to movement detection." << std::endl;
     this->performAction("ToggleOn");
}
