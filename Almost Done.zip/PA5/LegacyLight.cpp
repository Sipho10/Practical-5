#include "LegacyLight.h"

LegacyLight::LegacyLight()
{
    LegacyIsOn = false;
}

void LegacyLight::switchOn()
{
    LegacyIsOn = true;
}

void LegacyLight::switchOff()
{
    LegacyIsOn = false;
}