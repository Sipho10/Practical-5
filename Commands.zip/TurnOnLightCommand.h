#ifndef TURNONLIGHTCOMMAND_H
#define TURNONLIGHTCOMMAND_H

#include "Command.h"

class TurnOnLightCommand : public Command 
{
    private:
        SmartDevice* device;

    public:
        TurnOnLightCommand(SmartDevice* device);
        void execute();
};

#endif